# Dingfelder Training Catalog

## Completed / Live
- S.A.T. Visitor Orientation
- LOTO — Foundry Focus
- LOTO — Full Campus
- H₂S Awareness & SCBA
- Arc Flash & Electrical Safety
- Emergency Evacuation & Muster
- Hazard Communication / SDS / GHS
- PPE Fundamentals
- Forklift / Powered Industrial Truck Safety
- Fire Extinguisher Basics
- Molten Metal Awareness
- Furnace & Melt Deck Safety
- Sand System / Dust / Silica Awareness
- Crane, Ladle & Suspended Load Safety
- Propane Farm Operations Safety
- Food Plant Chemical Safety & Sanitation
- Ammonia Refrigeration Awareness
- Retail Backroom / Baler / Compactor Safety
- Walking-Working Surfaces / Slip Trip Fall
- Incident Reporting / Near Miss Response
- Contractor Safety Rules
- Severe Weather / Shelter / Accountability
- Confined Space Entry
- Respiratory Protection
- Hearing Conservation / Noise Exposure
- Hot Work / Welding / Cutting Permit Safety
- Machine Guarding — Molding Line & Conveyors
- Foundry Heat Stress & Burn Prevention
- Core Room / Binder / Ventilation Safety
- Shakeout / Cleaning / Grinding Area Safety
- Beam Mill Rolling Line Safety
- Overhead Crane & Rigging
- Hydraulic Stored Energy Safety
- Pinch Point / Crush Zone / Steel Handling

## Remaining
- Cut, Abrasion, and Hot Surface Protection
- Gas Wells / Wellhead Area Safety
- Drying / Stripping Equipment Safety
- Process Safety / Gas Release Control
- Line Opening / Bleeding / Purging Safety
- Tank Battery / Separator Area Safety
- Station Apparatus Bay Safety
- SCBA Inspection & Readiness
- Emergency Vehicle Ground Spotter Safety
- Fueling / Exhaust / Bay Ventilation Safety
- Stockroom Ladder / Cart / Pallet Safety
- Kitchen Burn, Fryer & Hot Oil Safety
- Knife Safety / Food Prep / Cut Prevention
- Walk-In Cooler / Freezer / Egress Safety
- Customer Area Slip / Spill / Incident Response

## Glass / Fiberglass Phase 1
- Glass Melt Furnace Safety
- Marble Melt Feed & Furnace Charging Safety
- Forehearth / Hot Glass Transfer Awareness
- Fiberizing Unit / Spinner / Attenuation Area Safety
- Mat Forming Line Safety
- Fiberglass Dust & Irritation Awareness
- Binder / Resin / Sizing Chemical Safety
- Jam Clearing / String-Up / Cleanout LOTO — Glass Mat Line
